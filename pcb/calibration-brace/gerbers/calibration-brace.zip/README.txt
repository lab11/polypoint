Material: FR4
Layers: 2
PCB Thickness: 0.062"
Layer Thickness: 1 oz
Surface Finish: Tin/Lead
Solder Mask: Green (2 side)

Layer Mapping:
Top Mask: calibration-brace-F_Mask.gbr
Top Copper: calibration-brace-F_Cu.gbr
Bottom Copper: calibration-brace-B_Cu.gbr
Bottom Mask: calibration-brace-B_Mask.gbr
Board Outline: calibration-brace-Edge_Cuts.gbr
NC Drill File: calibration-brace.drl
